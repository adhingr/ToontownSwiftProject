//
//  Invasions.swift
//  ToontownProject
//
//  Created by Mines Student on 4/13/22.
//

import Foundation

class Invasion: Identifiable {
    var districtName: String = ""
    var districtType: String = ""
    var districtProgress: String = ""
    var timeRemaining: Int = 0
    var cogImageString: String = ""
}
