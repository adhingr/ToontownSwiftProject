//
//  Population.swift
//  ToontownProject
//
//  Created by Mines Student on 4/13/22.
//

import Foundation

class Population {
    var population: Int = 0
}
