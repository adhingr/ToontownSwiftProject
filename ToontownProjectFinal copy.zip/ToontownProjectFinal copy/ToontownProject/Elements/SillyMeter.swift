//
//  SillyMeter.swift
//  ToontownProject
//
//  Created by Mines Student on 4/13/22.
//

import Foundation

class SillyMeter {
    
    var rewards = [String]()
    var rewardDescriptions = [String]()
    var rewardImageStrings = [String]()
    var winner: Bool = false
    var winnerString: String = ""
    var winnerImageString: String = ""
    var state: String = ""
    var hp: Int = 0
    
}
