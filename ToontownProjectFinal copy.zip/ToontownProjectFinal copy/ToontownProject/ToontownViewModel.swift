//
//  ToontownViewModel.swift
//  ToontownProject
//
//  Created by Mines Student on 4/13/22.
//

import Foundation
import SwiftUI
import Darwin


class ToontownViewModel: ObservableObject {
    
    
    @Published var sillymeter = SillyMeter()
    @Published var populationStuff = Population()
    @Published var fieldOfficeStuff = FieldOffice()
    @Published var invasionEachStuff = [Invasion]()
    @Published var fieldOfficeEachStuff = [FieldOffice]()
    
    func getSillyMeterData() -> Data? {
        let session = URLSession.shared
        var dataReceived: Data?
        var flag = 0
        //var dataString: String = ""
        let sem = DispatchSemaphore.init(value: 0)

        guard let url = URL(string: "https://www.toontownrewritten.com/api/sillymeter") else {
            print("No Internet Connection!!")
            exit(0)
        }
            let task = session.dataTask(with: url) { data, response, error in
                defer { sem.signal() }
                guard let data = data else {
                    flag = 1
                    return
                }
                if error != nil {
                    print("NO INTERNET CONNECTION")
                    return
                }

                //let jsonString = String(data: data, encoding: .utf8)
                dataReceived = data
                //dataString = jsonString!
            }

          task.resume()

          // This line will wait until the semaphore has been signaled
          // which will be once the data task has completed
          sem.wait()
        if flag == 1{
            return nil
        }
          if let sillyMeterData = try? JSONSerialization.jsonObject(with: dataReceived!, options: .allowFragments) as? [String: Any] {
                if let rewards = sillyMeterData["rewards"] as? [String] {
                    print(rewards)
                    sillymeter.rewards = rewards
                    for r in rewards{
                        if r == "Double Trap Experience"{
                            sillymeter.rewardImageStrings.append("trap")
                        }
                        if r == "Speedy Garden Growth"{
                            sillymeter.rewardImageStrings.append("garden")
                        }
                        if r == "Double Toon-Up Experience"{
                            sillymeter.rewardImageStrings.append("tu")
                        }
                        if r == "Double Drop Experience"{
                            sillymeter.rewardImageStrings.append("drop")
                        }
                        if r == "Double Throw Experience"{
                            sillymeter.rewardImageStrings.append("throw")
                        }
                        if r == "Double Squirt Experience"{
                            sillymeter.rewardImageStrings.append("squirt")
                        }
                        if r == "Double Lure Experience"{
                            sillymeter.rewardImageStrings.append("lure")
                        }
                        if r == "Double Sound Experience"{
                            sillymeter.rewardImageStrings.append("sound")
                        }
                        if r == "Overjoyed Laff Meters"{
                            sillymeter.rewardImageStrings.append("laff")
                        }
                        if r == "Decreased Fish Rarity"{
                            sillymeter.rewardImageStrings.append("fish")
                        }
                        if r == "Double Jellybeans"{
                            sillymeter.rewardImageStrings.append("beans")
                        }
                        if r == "Double Racing Tickets"{
                            sillymeter.rewardImageStrings.append("race")
                        }
                        if r == "Global Teleport Access"{
                            sillymeter.rewardImageStrings.append("teleport")
                        }
                        if r == "Doodle Trick Boost"{
                            sillymeter.rewardImageStrings.append("doodle")
                        }
                        
                    }
                    //print(type(of: rewards))
                }
                if let rewardDescriptions = sillyMeterData["rewardDescriptions"] as? [String] {
                    //print(rewardDescriptions)
                    sillymeter.rewardDescriptions = rewardDescriptions
                }
                if let winner = sillyMeterData["winner"] as? String {
                    print(winner)
                    sillymeter.winner = true
                    sillymeter.winnerString = winner
                    if winner == "Doodle Trick Boost"{
                        sillymeter.winnerImageString = "doodle"
                    }
                    if winner == "Overjoyed Laff Meters"{
                        sillymeter.winnerImageString = "laff"
                    }
                    if winner == "Decreased Fish Rarity"{
                        sillymeter.winnerImageString = "fish"
                    }
                    if winner == "Double Jellybeans"{
                        sillymeter.winnerImageString = "beans"
                    }
                    if winner == "Speedy Garden Growth"{
                        sillymeter.winnerImageString = "garden"
                    }
                    if winner == "Double Racing Tickets"{
                        sillymeter.winnerImageString = "race"
                    }
                    if winner == "Global Teleport Access"{
                        sillymeter.winnerImageString = "teleport"
                    }
                    if winner == "Double Toon-Up Experience"{
                        sillymeter.winnerImageString = "tu"
                    }
                    if winner == "Double Trap Experience"{
                        sillymeter.winnerImageString = "trap"
                    }
                    if winner == "Double Lure Experience"{
                        sillymeter.winnerImageString = "lure"
                    }
                    if winner == "Double Sound Experience"{
                        sillymeter.winnerImageString = "sound"
                    }
                    if winner == "Double Throw Experience"{
                        sillymeter.winnerImageString = "throw"
                    }
                    if winner == "Double Squirt Experience"{
                        sillymeter.winnerImageString = "squirt"
                    }
                    if winner == "Double Drop Experience"{
                        sillymeter.winnerImageString = "drop"
                    }
                    
                } else {
                    //print("NULL")
                    sillymeter.winner = false
                    sillymeter.winnerString = "No Winner"
                }
                if let state = sillyMeterData["state"] as? String {
                    //print(state)
                    sillymeter.state = state
                }
                if let hp = sillyMeterData["hp"] as? Int {
                    //print(hp)
                    sillymeter.hp = hp
                }
            }
          return dataReceived
    }
    
    
    func getInvasionData() -> Data? {
        let session = URLSession.shared
        var dataReceived: Data?
        var flag = 0
        //var dataString: String = ""
        let sem = DispatchSemaphore.init(value: 0)

        let url = URL(string: "https://www.toontownrewritten.com/api/invasions")
            let task = session.dataTask(with: url!) { data, response, error in
                defer { sem.signal() }
                guard let data = data else {
                    print("NO INTERNET!!")
                    flag = 1
                    return
                }
                if error != nil {
                    print("NO INTERNET CONNECTION")
                    return
                }

                //let jsonString = String(data: data, encoding: .utf8)
                dataReceived = data
                //dataString = jsonString!
            }

          task.resume()

          // This line will wait until the semaphore has been signaled
          // which will be once the data task has completed
          sem.wait()
        if flag == 1{
            return nil
        }
        if let invasionData = try? JSONSerialization.jsonObject(with: dataReceived!, options: .allowFragments) as? [String: Any] {
            if let invasions = invasionData["invasions"] as? [String: [String: Any]] {
                var latestInvasion: [Invasion] = []
                
                for key in invasions.keys { 
                    let tempInvasion = Invasion()
                    let tempInvasionNameString = String(key)
                    let tempInvasionTypeString = (invasions[key]!["type"]! as? String)
                    let tempInvasionProgressString = (invasions[key]!["progress"]! as? String)
                    tempInvasion.districtName = tempInvasionNameString
                    tempInvasion.districtType = tempInvasionTypeString!
                    tempInvasion.districtProgress = tempInvasionProgressString!
                    
                    let components = tempInvasionProgressString?.components(separatedBy: "/")
                    let currCogs = (Double(components![1])! - Double(components![0])!)
                    var temp = 0.7 * currCogs
                    temp = temp / 100
                    tempInvasion.timeRemaining = Int(temp)
                    print(tempInvasion.districtType)
                    let newString = tempInvasion.districtType.replacingOccurrences(of: "\u{0003}", with: "")
                    switch newString{
                    case "Flunky":
                        tempInvasion.cogImageString = "flunky"
                    case "Pencil Pusher":
                        tempInvasion.cogImageString = "pencil_pusher"
                    case "Yesman":
                        tempInvasion.cogImageString = "yesman"
                    case "Micromanager":
                        tempInvasion.cogImageString = "micromanager"
                    case "Downsizer":
                        tempInvasion.cogImageString = "downsizer"
                    case "Head Hunter":
                        tempInvasion.cogImageString = "head_hunter"
                    case "Corporate Raider":
                        tempInvasion.cogImageString = "corporate_raider"
                    case "The Big Cheese":
                        tempInvasion.cogImageString = "the_big_cheese"
                    case "Short Change":
                        tempInvasion.cogImageString = "short_change"
                    case "Penny Pincher":
                        tempInvasion.cogImageString = "penny_pincher"
                    case "Tightwad":
                        tempInvasion.cogImageString = "tightwad"
                    case "Bean Counter":
                        tempInvasion.cogImageString = "bean_counter"
                    case "Number Cruncher":
                        tempInvasion.cogImageString = "number_cruncher"
                    case "Money Bags":
                        tempInvasion.cogImageString = "money_bags"
                    case "Loan Shark":
                        tempInvasion.cogImageString = "loan_shark"
                    case "Robber Baron":
                        tempInvasion.cogImageString = "robber_baron"
                    case "Bottom Feeder":
                        tempInvasion.cogImageString = "bottom_feeder"
                    case "Bloodsucker":
                        tempInvasion.cogImageString = "bloodsucker"
                    //case "Bloodsucker":
                    //   tempInvasion.cogImageString = "bloodsucker"
                    case "Double Talker":
                        tempInvasion.cogImageString = "double_talker"
                    case "Ambulance Chaser":
                        tempInvasion.cogImageString = "ambulance_chaser"
                    case "Back Stabber":
                        tempInvasion.cogImageString = "back_stabber"
                    case "Spin Doctor":
                        tempInvasion.cogImageString = "spin_doctor"
                    case "Legal Eagle":
                        tempInvasion.cogImageString = "legal_eagle"
                    case "Big Wig":
                        tempInvasion.cogImageString = "big_wig"
                    case "Cold Caller":
                        tempInvasion.cogImageString = "cold_caller"
                    case "Telemarketer":
                        tempInvasion.cogImageString = "telemarketer"
                    case "Name Dropper":
                        tempInvasion.cogImageString = "name_dropper"
                    case "Glad Hander":
                        tempInvasion.cogImageString = "glad_hander"
                    case "Mover & Shaker":
                        tempInvasion.cogImageString = "mover_shaker"
                    case "Two-Face":
                        tempInvasion.cogImageString = "two_face"
                    case "The Mingler":
                        tempInvasion.cogImageString = "mingler"
                    case "Mr. Hollywood":
                        tempInvasion.cogImageString = "hollywood"
                    default:
                        tempInvasion.cogImageString = ""
                    }
                    
                    
                    latestInvasion.append(tempInvasion)
                }
                //print(invasions)
                invasionEachStuff = latestInvasion
            }
        }
          
          return dataReceived
    }
    
    func getPopulationData() -> Data? {
        //var populationhaha = Population()
        var flag = 0
        let session = URLSession.shared
        var dataReceived: Data?
        //var dataString: String = ""
        let sem = DispatchSemaphore.init(value: 0)

        guard let url = URL(string: "https://www.toontownrewritten.com/api/population") else {
            print("No Internet connection!")
            return nil
        }
            let task = session.dataTask(with: url) { data, response, error in
                defer { sem.signal() }
                guard let data = data else {
                    print("No Internet Connection")
                    flag = 1
                    return
                }
                if error != nil {
                    print("NO INTERNET CONNECTION")
                    return
                }

                //let jsonString = String(data: data, encoding: .utf8)
                dataReceived = data
                //dataString = jsonString!
            }

          task.resume()

          // This line will wait until the semaphore has been signaled
          // which will be once the data task has completed
          sem.wait()
        if flag == 1{
            return nil
        }
        if let populationData = try? JSONSerialization.jsonObject(with: dataReceived!, options: .allowFragments) as? [String: Any] {
            if let populations = populationData["totalPopulation"] as? Int {
                print("population: \(populations)")
                //populationhaha.population = populations
                //populationStuff = populationhaha
                print(populationStuff.population)
                populationStuff.population = populations
                print(populationStuff.population)
            }
        }
          return dataReceived
    }
    
    func getFieldOfficeData() -> Data? {
        var latestFieldOffice: [FieldOffice] = []
        let session = URLSession.shared
        var dataReceived: Data?
        var flag = 0
        //var dataString: String = ""
        let sem = DispatchSemaphore.init(value: 0)

        let url = URL(string: "https://www.toontownrewritten.com/api/fieldoffices")
            let task = session.dataTask(with: url!) { data, response, error in
                defer { sem.signal() }
                guard let data = data else {
                    flag = 1
                    return
                }
                if error != nil {
                    print("NO INTERNET CONNECTION")
                    return
                }

                //let jsonString = String(data: data, encoding: .utf8)
                dataReceived = data
                //dataString = jsonString!
            }

          task.resume()

          // This line will wait until the semaphore has been signaled
          // which will be once the data task has completed
          sem.wait()
        if flag == 1{
            return nil
        }
        if let fieldOfficeData = try? JSONSerialization.jsonObject(with: dataReceived!, options: .allowFragments) as? [String: Any] {
            if let fieldOffice = fieldOfficeData["fieldOffices"] as? [String: [String: Any]] {
                print("Helloooo")
                for key in fieldOffice.keys {
                    var tempStreet: String
                    let tempOffice = FieldOffice()
                    let tempOfficeZone = Int(key)
                    var tempOfficeDifficulty = (fieldOffice[key]!["difficulty"]! as? Int)
                    let tempOfficeAnnexes = (fieldOffice[key]!["annexes"]! as? Int)
                    let tempOfficeOpen = (fieldOffice[key]!["open"]! as? Bool)
                    var tempOpenString: String
                    var tempImageString: String
                    if tempOfficeOpen == true{
                        tempOpenString = "Open"
                    } else {
                        tempOpenString = "Closed"
                    }
                    
                    switch tempOfficeZone{
                    case 3100:
                        tempStreet = "Walrus Way"
                        tempImageString = "walrus"
                    case 3200:
                        tempStreet = "Sleet Street"
                        tempImageString = "walrus"
                    case 3300:
                        tempStreet = "Polar Place"
                        tempImageString = "walrus"
                    case 4100:
                        tempStreet = "Alto Avenue"
                        tempImageString = "alto"
                    case 4200:
                        tempStreet = "Baritone Boulevard"
                        tempImageString = "alto"
                    case 4300:
                        tempStreet = "Tenor Terrace"
                        tempImageString = "alto"
                    case 5100:
                        tempStreet = "Elm Street"
                        tempImageString = "maple"
                    case 5200:
                        tempStreet = "Maple Street"
                        tempImageString = "maple"
                    case 5300:
                        tempStreet = "Oak Street"
                        tempImageString = "maple"
                    case 9100:
                        tempStreet = "Lullaby Lane"
                        tempImageString = "pajama"
                    case 9200:
                        tempStreet = "Pajama Place"
                        tempImageString = "pajama"
                    default:
                        tempStreet = "Error getting street"
                        tempImageString = "pajama"
                    }
                    if tempOfficeDifficulty == 0{
                        tempOfficeDifficulty = 1
                    }
                    else if tempOfficeDifficulty == 1{
                        tempOfficeDifficulty = 2
                    }
                    else if tempOfficeDifficulty == 2{
                        tempOfficeDifficulty = 3
                    }
                    
                    
                    tempOffice.zone = tempOfficeZone!
                    tempOffice.difficulty = tempOfficeDifficulty!
                    tempOffice.street = tempStreet
                    tempOffice.annexes = tempOfficeAnnexes!
                    tempOffice.open = tempOpenString
                    tempOffice.imageString = tempImageString
                    
                    latestFieldOffice.append(tempOffice)
                }
                fieldOfficeEachStuff = latestFieldOffice
            }
            
        }
          return dataReceived
    }
    
    
}
