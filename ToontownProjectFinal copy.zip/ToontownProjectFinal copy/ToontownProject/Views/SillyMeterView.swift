//
//  SillyMeterView.swift
//  ToontownProject
//
//  Created by Mines Student on 4/18/22.
//

import SwiftUI

struct myHeader: View {
    var body: some View {
        Text("Silly Meter")
            .bold()
    }
}

struct SillyMeterView: View {
    @Binding var sillymeterdata: SillyMeter
    var body: some View {
        VStack{
            myHeader()
            HStack{
                VStack{
                    Text("TEAMS")
                    //Spacer()
                    if sillymeterdata.winner == false && !sillymeterdata.rewards.isEmpty{
                        
                        Text("\(sillymeterdata.rewards[0])")
                        Image("\(sillymeterdata.rewardImageStrings[0])")
                        Text("\(sillymeterdata.rewards[1])")
                        Image("\(sillymeterdata.rewardImageStrings[1])")
                        Text("\(sillymeterdata.rewards[2])")
                        Image("\(sillymeterdata.rewardImageStrings[2])")
                    } else if (sillymeterdata.winnerString != "") {
                        Text("WINNER")
                        Text("\(sillymeterdata.winnerString)")
                        Image("\(sillymeterdata.winnerImageString)")
                    }
                }
            }
        }
        Spacer()
    }
}

/*
struct SillyMeterView_Previews: PreviewProvider {
    static var previews: some View {
        SillyMeterView()
    }
}
*/
